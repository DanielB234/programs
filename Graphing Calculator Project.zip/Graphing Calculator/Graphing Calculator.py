import math#my umported python libraries
import pygame, string
from pygame.locals import *

def Grid(screen, Colours, Origin):#responsible for the drawing of the gird in the background
    for x in range(75):
        if x % 5 == 1:#so one in five lines will stand out
            Grey = Colours["CoordGrey"]
        else:
            Grey = Colours["GridGrey"]
        pygame.draw.line(screen, Grey, (360,(10*x+Origin[1])%750),(1080,(10*x+Origin[1])%750),1)#these two lines represent the grid in the background
        #%750 allows the lines do be redrawn at the bottom/top/left/right when they leave the screen on the over side without losing the one in five highlighted lines
        pygame.draw.line(screen, Grey, (360+(10*x+Origin[0])%750,0),(360+(10*x+Origin[0])%750,1080),1)
    pygame.draw.line(screen, Colours["Black"], (360,360+Origin[1]),(1080,360+Origin[1]),1)#the axis is drawn with these last two lines of code
    pygame.draw.line(screen, Colours["Black"], (720+Origin[0],0),(720+Origin[0],720),1)


def Equations(screen,Colours,EquationOne,EquationListOne,intermediate,ScrollY,font):#draws some of the boxes on the left side
    pygame.draw.rect(screen, Colours["White"], (0, 0, 360, 480))#these lines draw the box around the equations
    pygame.draw.line(screen, Colours["GridGrey"], (0,40),(360, 40),1)
    Temp = []#finds number of Equations in use so the dividers between the equations can be drawn
    try:
        for y in EquationListOne:
            Temp.append("".join(y))
    except:
        pass
    intermediate.fill(Colours["White"])
    for x in range(len(Temp)+1):#decides how many dividers between equations should be drawn
        pygame.draw.line(intermediate, Colours["GridGrey"], (0,110+x*70),(360, 110+x*70),1)
    pygame.draw.rect(screen, Colours["White"], (0, 480, 360, 720))#these last two lines are for drawing the box around the buttons
    pygame.draw.rect(screen, Colours["GridGrey"], (0, 480, 360, 720),1)

def get_key(Scroll,ScrollY,EquationOne,EquationListOne):#decides which letter was typed and  whether the equation tab or graph should scroll
    Key = 0#this variable displays marks the key that is pushed
    Temp = []
    try:
        for x in EquationListOne:
            Temp.append("".join(x))
    except:
        pass
    mouse = pygame.mouse.get_pos()#position of the mouse on the program
    event = pygame.event.poll()#finds all key presses and scrolls
    for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN or event.type == MOUSEBUTTONUP:#samples the scroll
            if mouse[0] >= 360:#on the graphical side
                if event.button == 4:
                    Scroll = Scroll * 2
                if event.button == 5:
                    Scroll = Scroll / 2 #this section relates to zooming in and out of the graph
            elif mouse[0] < 360 and mouse[1] <= 480:#on the equation tab, ScrollY means a vertical scroll
                if len(EquationListOne) > 5:
                    if event.button == 4:
                        ScrollY = min(ScrollY + 40,0)#scroll up
                    elif event.button == 5:
                        ScrollY = max(ScrollY - 40,-(len(Temp)-5)*70)#scroll down
    if event.type == KEYDOWN:
        Key = event.key#this line will select the key that was pressed
        # Key
##        print Key
        if event.key == pygame.K_0 and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            #these statements check if the shift key was pressed and may change the key if needed
            Key = K_RIGHTPAREN#closebracket
        elif event.key == pygame.K_9 and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            Key = K_LEFTPAREN#openbracket
        elif event.key == pygame.K_8 and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            Key = K_ASTERISK
        elif event.key == pygame.K_6 and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            Key = K_CARET
        elif event.key == pygame.K_EQUALS and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            Key = K_PLUS
        elif event.key == pygame.K_1 and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            Key = K_EXCLAIM
        elif event.key == pygame.K_LESS and pygame.key.get_mods() & pygame.KMOD_SHIFT:
            Key = K_AT#this changes the symbol to the "@" sign instead of the "|" as complications arise from entering the "|" into the equation
        if (event.key >= 0x100 and event.key <= 0x109):#converts some of the numbers on the numpad
            Key -= 0xD0
##        print Key
        return Key,Scroll,ScrollY#returns a code for a key if it was pressed, the level of zoom, and the change in the scroll in the equation tsab
    else:
        return "",Scroll,ScrollY

def TextBox(screen, Message,font,Colours,question,intermediate,Question,FinishCount):
    #this deals with the error correction and drawing of the grammatical equation, this is a long and complex function as it cannot simply be solved in some cases
    #and thus uses a heuristic algorithm to attain the best possible formatting
    Message = Message.replace("sqrt","q")#"q" will be converted to a square root sign
    Message = Message.replace("atnh","atanh(")
    Message = Message.replace("asnh","asinh(")
    Message = Message.replace("acsh","acosh(")
    Message = Message.replace("cos","cos(")
    Message = Message.replace("sin","sin(")
    Message = Message.replace("tan","tan(")
    Message = Message.replace("(h","h(")
    if Question == FinishCount and Question != 0:
        Message = Message+"_"#if the question is selected this will be added to the end to indicate where the person is adding text to
    if FinishCount == 0 and Question == 0:
        Message = Message+"_"# the underscore denotes the position where the next character will be added, this way the user knows if they are going to type in indices or other ways
    Message = Message.replace("^a","^")#
    if Message[-2:] == "__":
        Message = Message[:-1]
    Message = Message.replace("@","|")#stages like this will make the graph more presentable
    Message = Message.replace("**","^")
    SuperScript = list(Message)# using a list makes it easier to process
    #some of these variables decide whether the letter drawn is an indice, base, square root, part of a fraction or just a normal number
    #some indicate how far to the right each letter must be positioned
    Pos = 0#for fractions
    count = 0# denotes the space moved when the numbers are standard (not indices or fractions), each letter moves 12 coordinates
    countUp = -1#space moved by numerator
    countDown = -1#space moved by denominator
    countFract = 0#largest space moved by numerator or denominator fraction
    Indices = 0#denotes when indices are in use
    IndicesCount = 0#space moved by indices characters, each letter moves 6 coordinates
    countPos = 0
    Sqrt = 0#denotes when square root is active
    PosCount = 0
    SqrtStop = 0# when and where to draw the tick part of the square root
    IndicesCountUp = -1# the space moved in the numerator of a fraction by indices
    IndicesCountDown = -1
    IndicesCountFract = 0
    EnterOrder = []#a list marking when certain conditions were applied to the list i.e. indices or fractions
    Log = ""
    print Message
    for a in range(len(SuperScript)):#this takes each letter one at a time
        if SuperScript[a] == "/" and Indices == 0 and Pos == 0:#when the current letter is a "/", the program sets pos to 1 and  skips it
            PosCount +=1
            Pos = 1#for the top of a fraction
            EnterOrder.append("/")
        elif SuperScript[a] == "D" and Indices == 0 and Pos != 0:#switches to bottom of fraction
            Pos = -1#-1 marks when it is inthe denominator
        elif SuperScript[a] == "D" and (Indices != 0 or Pos == 0):#this if statement is for when
            pass
        elif SuperScript[a] == "q" and Pos == 0:
            SqrtStop = 0
            EnterOrder.append("q")
            Sqrt = 1#this notes when there is a square root
        elif SuperScript[a] == "q" and Pos != 0:
            Sqrt = 1
            SqrtStop = 0
            EnterOrder.append("q")
        elif SuperScript[a] == "^" and Indices == 0:#this marks indices
            Indices = 1
            EnterOrder.append("^")
        elif SuperScript[a] == "R":#this is what is used to leave fractions, square roots, bases and indices, marked by right arrow key
                print EnterOrder
                try:
                    if EnterOrder[-1] == "/":#exiting fractions
                        Pos = 0
                        count +=1
                        countUp = -1
                        countDown = -1
                    elif EnterOrder[-1] == "^":#exiting bases and indices
                        if Indices == 2:
                            Indices = 1
                        elif Indices == -2:
                            Indices = -1
                        else:
                            if Pos != 0:
                                Indices = 0
                                IndicesCount += 1
                            else:
                                if Indices == 2:
                                    Indices = 1
                                else:
                                    Indices = 0
                                countUp = -1
                                countDown = -1
                                IndicesCountUp = -1
                                IndicesCountDown = -1
                    elif EnterOrder[-1] == "q":#exiting square root
                        Sqrt = 0
                    del EnterOrder[-1]
                except:
                    pass
        else:
            if SuperScript[a] == "l" or SuperScript[a] == "o" or SuperScript[a] == "g" or SuperScript[a] == "n":
                if SuperScript[a] == "l":#these if statements detect lograrithms both natural and otherwise
                    Log = "l"
                elif SuperScript[a] == "o" and Log == "l":
                    Log += "o"
                elif SuperScript[a] == "n" and Log == "l":
                    Log += "n"
                    SuperScript[a] = "n("
                elif SuperScript[a] == "g" and Log == "lo":
                    Log += "g"
                    SuperScript[a] = "g("
            if SuperScript[a-1] == "g(" and Log == "log":#simplifies writing of logaritms
                if Indices == 0:
                    Indices = -1
                elif Indices == 1:#for when logarithms are contained in indices
                    Indices == 2
                if Pos == 1:
                    countUp += 1
                elif Pos == -1:
                    countDown += 1
                EnterOrder.append("^")
            if SuperScript[a] == "^" and Indices == -1:#for when indices are contained in powers
                Indices = -2
                EnterOrder.append("^")
            if Pos == 1:
                if Indices == 0:
                    countUp += 1
                else:
                    IndicesCountUp += 1
                countFract = countUp
                IndicesCountFract = IndicesCountUp#decides how far anything after the fraction should be moved along
            if Pos == -1:
                if Indices == 0:
                    countDown += 1
                else:
                    IndicesCountDown += 1
                countFract = countDown
                IndicesCountFract = IndicesCountDown
##            print Indices
            if Indices == 0:#draws text that isnt base or indices
                intermediate.blit(font.render(SuperScript[a], True, Colours["Black"]),((10+12*count - countPos*6+ countFract*12 + IndicesCount*6,65 +(question-1)*70 - Pos*10)))
            if Indices != 0:#used for indices and bases
                font = pygame.font.SysFont("Courier New", 10, False, False)#font size changes as they are drawn smaller
                intermediate.blit(font.render(SuperScript[a], True, Colours["Black"]),((10+12*count + IndicesCount*6+ IndicesCountFract*6 +countFract*12+math.fabs(PosCount)*12,70-(round(Indices/1.5))*5 +(question-1)*70 - Pos*10)))
                font = pygame.font.SysFont("Courier New", 20, False, False)
            if Pos == 0:
                if Indices == 0:
                    count += max(1,countUp,countDown)#this decides how much further to increment the position
                    if SuperScript[a] == "g(" or SuperScript[a] == "n(":#used when superscript[a] is expanded with an open bracket
                        count += 1
                else:
                    IndicesCount += max(1,IndicesCountUp,IndicesCountDown)#decides position increment of indices
                    if SuperScript[a] == "g(" or SuperScript[a] == "n(":
                        IndicesCount += 1
            if Pos != 0:
                #the line drawn for fractions
                pygame.draw.line(intermediate, Colours["Black"],(12 + 12*count+countFract*6+IndicesCountFract*6 + IndicesCount*6,75+(question-1)*70),(20+12*count+IndicesCount*6+countFract*12+IndicesCountFract*6+math.fabs(PosCount)*6,75 +(question-1)*70),1)
            if Sqrt == 1:
                if Indices == 0:
                    #the illustration of the square root symbol
                    if SqrtStop == 0:#draws tick in fromt of square root symbol
                        pygame.draw.line(intermediate, Colours["Black"],(-6+12*count+IndicesCount*6+countFract*6+IndicesCountFract*6+math.fabs(PosCount)*14,84+(question-1)*70-Pos*12),(-2+12*count+IndicesCount*6+countFract*12+IndicesCountFract*6+math.fabs(PosCount)*14,65 +(question-1)*70-Pos*12),1)
                        pygame.draw.line(intermediate, Colours["Black"],(-10+12*count+IndicesCount*6+countFract*6+IndicesCountFract*6+math.fabs(PosCount)*14,81+(question-1)*70-Pos*12),(-6+12*count+IndicesCount*6+countFract*12+IndicesCountFract*6+math.fabs(PosCount)*14,84 +(question-1)*70-Pos*12),1)
                        SqrtStop = 1#makes sure it is only drawin once
                    #line of code below is for the line above the maths in the square root
                    pygame.draw.line(intermediate, Colours["Black"],(-2+12*count+IndicesCount*6+countFract*12+math.fabs(PosCount)*8,65+(question-1)*70-Pos*12),(12+12*count+IndicesCount*6+countFract*12+IndicesCountFract*6+math.fabs(PosCount)*12,65 +(question-1)*70-Pos*12),1)
                    if SuperScript[a] == "g(" or SuperScript[a] == "n(":
                        pygame.draw.line(intermediate, Colours["Black"],(-12+12*count+IndicesCount*6+countFract*12+math.fabs(PosCount)*8,65+(question-1)*70-Pos*12),(12+12*count+IndicesCount*6+countFract*12+IndicesCountFract*6+math.fabs(PosCount)*12,65 +(question-1)*70-Pos*12),1)
##                else:

class Button():#this helps unpack the buttons
    def __init__(self,screen,intermediate,Colours,font,buttons,buttonsone,quitbuttons,ScrollY):
        self.Sym = [["^2 ","^a "," e"," ("," )"," |"],#the array of values that will be bound to the buttons sprites
           [" 7"," 8"," 9"," C"," CE","pi"],
           [" 4"," 5"," 6"," *"," /","ln"],
           [" 1"," 2"," 3"," +"," -","sqrt"],
           [" 0"," ."," x","rght","down","log"],
           ["sin","cos","tan","asin","acos","atan"]]
        self.SymOne = ["sinh","cosh","tanh","asnh","acsh","atnh"]#the list of values that will be bound to the buttonsone sprites
        self.intermediate = intermediate
        self.Colours = Colours
        self.screen = screen
        self.font = font
        self.Type = ""
        self.count = 0
        self.Close = [0,False]
        self.ScrollY = ScrollY
        self.buttons = buttons
        self.buttonsone = buttonsone
        self.quitbuttons = quitbuttons

    def ButtonMaker(self,buttons,buttonsone,quitbuttons):#marks grid references for buttons and then places them, this method only runs once
        for y in range(6):#buttons from the pop out tab
            self.letter = self.SymOne[y]
            self.button = Join(self.letter,"button.png")
            self.button.rect.x = 361#since they are all plotted at the same x coordinate, this is constant
            self.button.rect.y = 481+40*y#each button is plotted 40 coordinates below its predecessor
            buttonsone.add(self.button)#adds them to the sprites group
        self.Symbols(self.screen,self.font,self.Colours,self.SymOne,0)
        for x in range(6):#buttons in the main display
            for y in range(6):
                self.letter = self.Sym[y][x]
                self.button = Join(self.letter, "button.png")
                self.button.rect.x =  1+60*x#these buttons are drawn in two dimensions, making both coordinates vary
                self.button.rect.y =  481 + 40*y
                buttons.add(self.button)
        self.Symbols(self.screen,self.font,self.Colours,self.Sym,1)
        buttonsone.draw(self.screen)#draws sprites on screen
        buttons.draw(self.screen)#this is the initial remove button for the first equation box
        self.button = Join("","remove.png")
        self.button.rect.x = 322
        self.button.rect.y = 40
        quitbuttons.add(self.button)
        quitbuttons.draw(self.intermediate)#remove buttons are joined to the intermediate

    def Symbols(self,screen,font,Colours,Sym,z):#this draws the text in front of the buttons
        font = pygame.font.SysFont("Courier New", 20, False, False)
        for y in range(6):
            if z == 0:
                screen.blit(font.render((Sym[y]),True,Colours["Black"]),(368,488+39*y))#for the extra buttons
            elif z == 1:
                for x in range(6):
                    screen.blit(font.render((Sym[y][x]),True,Colours["Black"]),(x*59+8,488+39*y))#for the main button block

    def Detection(self,mouse,click,Tab):#detects when a user hovers over a button and divines the buttons purpose should the user click it
        for y in self.quitbuttons:
            if y.rect.collidepoint([mouse[0],mouse[1]-self.ScrollY]):#finds when user hovers over a certain button
                y.image = pygame.image.load("remove hover.png").convert()#replaces the current image with the darkened hover button
                if click[0] == 1:
                    self.Close[0] = y.letter#adds the equation number to the delete queue
                    self.Close[1] = True#prevents deletion of multiple equations
                    try:
                        self.Close[0] += "t"
                    except:
                        pass
            else:
                y.image = pygame.image.load("remove.png").convert()
            self.count +=1
        for y in self.buttonsone:#see above
            if y.rect.collidepoint(mouse) and Tab == True:
                y.image = pygame.image.load("hover button.png").convert()
                if click[0] == 1:
                    self.Type = y.letter#sets type as the present letter
            else:
                y.image = pygame.image.load("button.png").convert()
        for y in self.buttons:
            if y.rect.collidepoint(mouse):
                y.image = pygame.image.load("hover button.png").convert()
                if click[0] == 1:
                    self.Type = y.letter
            else:
                y.image = pygame.image.load("button.png").convert()
        return self.Type,self.Close

    def Update(self,question):#used when a new equation is added to draw a new button
        if question != len(self.quitbuttons):#when an equation is added or deleted
            self.quitbuttons.empty()#redraws the list
            for y in range(1,question+1):
                self.letter = y
                self.button = Join(self.letter,"remove.png")
                self.button.rect.x =  322
                self.button.rect.y =  70*y-30
                self.quitbuttons.add(self.button)

    def Place(self,mouse,click,Tab,TabOne):#draws the buttons after they are created
        if mouse[0] < 360 and mouse[1] > 480 and Tab == False:#initial opening of buttons tab
            pygame.draw.rect(self.screen, self.Colours["White"], (0, 480, 420, 720))
            pygame.draw.rect(self.screen, self.Colours["GridGrey"], (0, 480, 420, 720),1)
            self.buttonsone.draw(self.screen)
            self.Symbols(self.screen,self.font,self.Colours,self.SymOne,0)
            Tab = True
        if mouse[0] < 420 and mouse[1] > 480 and Tab == True:#keeping buttons tab open
            pygame.draw.rect(self.screen, self.Colours["White"], (0, 480, 420, 720))
            pygame.draw.rect(self.screen, self.Colours["GridGrey"], (0, 480, 420, 720),1)
            self.buttonsone.draw(self.screen)
            self.Symbols(self.screen,self.font,self.Colours,self.SymOne,0)
            Tab = True
        if (mouse[0] > 420 or mouse[1] < 480) and Tab == True:#closing buttons tab
            Tab = False
            TabOne = 1
        pygame.draw.rect(self.screen, self.Colours["White"], (0, 480, 360, 720))
        pygame.draw.rect(self.screen, self.Colours["GridGrey"], (0, 480, 360, 720),1)
        self.buttons.draw(self.screen)#draws initial buttons in tab
        self.quitbuttons.draw(self.intermediate)#draws red x's
        self.Symbols(self.screen,self.font,self.Colours,self.Sym,1)
        return Tab,TabOne

class Join(pygame.sprite.Sprite):
    def __init__(self, letter, PNG_file):
        super(Join, self).__init__()
        self.image = pygame.image.load(PNG_file).convert()
        self.rect = self.image.get_rect()
        self.letter = letter#links the corresponding letter to the button

def Enter(screen, question,font,Colours,Key,EquationList,Equation,intermediate,Question):#this decideshow the letters typed are added to the program
    Equation = Equation.replace("&","|")
    Equation = list(Equation)
    try:
        if Key == K_BACKSPACE:
            if Question != 0 and Question != question:
                del EquationList[Question-1][-1]
            else:
                Equation = Equation[0:-1]
        elif Key == K_RETURN:#this will move on to the next equation
            if Question == 0:
                question += 1
            Question = 0
            EquationList.append(Equation)
            Equation = ""
        elif Key <= 127 or Key == K_DOWN or Key == K_RIGHT:
            if Question != 0:
                EquationList[Question-1].append(chr(Key))#this will add to the equation when it is entered on the keyboard
            else:
                if Key == K_DOWN:
                    Denom = [0,0]
                    for x in Equation:
                        if x == "/":
                            Denom[0] += 1
                        elif x == "D":
                            Denom[1] += 1
                    if Denom[0] >= Denom[1]+1:
                        Equation.append("D")
                elif Key == K_RIGHT:
                    Equation.append("R")
                else:
                    Equation.append(chr(Key))#this adds characters to the automatically selected equation
        return "".join(Equation),EquationList,question,Question
    except:
        return "".join(Equation),EquationList,question,Question

def Line(screen, LineColours,ColourCount ,FinalEquation,Scroll,Origin):#this is the function that is used to graph the equation itself
    mouse = pygame.mouse.get_pos()
    Asymptote = 0#this is used to mark when an asymptote is present
    for a in range(2):#drawn in 2 directions out from the centre of the graph interface
        Coords = None
        CoordsOne = None
        for b in range(0,361):#the graph takes samples at each coordinate from the centre to the edge (360 coordinates)
            b = float(b)
            x = b/10#to account for the precision
            if a == 1:
                x=-x#so the graph is drawn in both direction
            try:
                try:
                    y = eval(FinalEquation)#the translated equation (see rearranger) has the x value ran through it to find y
                except ZeroDivisionError:
                    print x
                    xOne = x
                    x += 0.0001
                    y = eval(FinalEquation)
                    print y
                    x = xOne
                else:
                    y = eval(FinalEquation)
##                print x,y,
                if Coords!= None and CoordsOne != None:
##                    print x,y,Coords,CoordsOne
                    if Asymptote  == 0:
                        #under normal circumstances this is from where the graph will be drawn be connection two coordinates separated by one x coordinate
                        pygame.draw.line(screen, LineColours[ColourCount], (720+Coords[0]*10,360-Coords[1]*10),(720+CoordsOne[0]*10,360-CoordsOne[1]*10),2)
                    if CoordsOne[1] < Coords[1] and Coords[1] > y and (math.fabs(Coords[1]-y) > 5*Scroll or math.fabs(CoordsOne[1]-Coords[1]) > 5*Scroll) and Asymptote == 0:
                        Asymptote = 1#this part marks when an asymptote goes from a high point
                        pygame.draw.line(screen, LineColours[ColourCount], (720+Coords[0]*10,360-Coords[1]*10),(720+Coords[0]*10,0),2)#draws to the top of the screen
                        xOne = x#from this point the program decides whether to draw the next asymptote up or down
                        x = math.fabs(x)
                        float(x)
                        x += 0.1
                        if a == 1:
                            x = -x
                        yOne = eval(FinalEquation)#this simulates the next coordinate to find its direction, and uses it to decide the direction of the asymptote
                        x = xOne
                        if yOne < y:
                            pygame.draw.line(screen, LineColours[ColourCount], (720+x*10,360-y*10),(720+x*10,0),2)
                        else:
                            pygame.draw.line(screen, LineColours[ColourCount], (720+x*10,360-y*10),(720+x*10,720),2)#draws to the bottom of the screen
                    elif CoordsOne[1] > Coords[1] and Coords[1] < y and (math.fabs(Coords[1]-y) > 5*Scroll or math.fabs(CoordsOne[1]-Coords[1]) > 5*Scroll) and Asymptote == 0:
                        Asymptote = 1#this part marks when an asymptote goes from a low point
                        pygame.draw.line(screen, LineColours[ColourCount], (720+Coords[0]*10,360-Coords[1]*10),(720+Coords[0]*10,720),2)
                        xOne = x
                        x = math.fabs(x)
                        float(x)
                        x += 0.1
                        if a == 1:
                            x = -x
                        yOne = eval(FinalEquation)
                        x = xOne
                        if yOne > y:
                            pygame.draw.line(screen, LineColours[ColourCount], (720+x*10,360-y*10),(720+x*10,720),2)
                        else:
                            pygame.draw.line(screen, LineColours[ColourCount], (720+x*10,360-y*10),(720+x*10,0),2)
                    elif Asymptote != 0 :
                        Asymptote = 0
                if Coords != None:
                    CoordsOne = [Coords[0],Coords[1]]
                else:
                    CoordsOne = [x,y]
                Coords = [x,y]
            except:
                pass



def Coordinates(screen, Colours,font,Origin,Scroll):#this draws the coordinates next to the axes
    count = 0
    mouse = pygame.mouse.get_pos()
    for y in range(4):
        if y < 2:
            for x in range(10+int(math.fabs(Origin[0]/10))):#the coordinates along the x axis
                if count/Scroll %1 == 0:
                    zoom = int(count/Scroll)#this makes the coordinates fit with the zoom
                else:
                    zoom = count/Scroll
                e = ""
                zoom = str(zoom)
                print
                if len(zoom) > 7:#this system prevents the coordinates from overlapping on the x axis (as they are side by side)
                    Count = 0
                    for z in zoom:
                        if z == "e":
                            e = (zoom)[(Count-1):]
                            break
                        Count += 1
                    if e == "":
                        if zoom[0] == "-":
                            zoom = zoom[:2] + "." + zoom[1:3]+ "e+" + str(len(zoom[3:]))
                        else:
                            zoom = zoom[0] + "." + zoom[0:3]+ "e+" + str(len(zoom[3:]))
                    else:
                        zoom = zoom[:3] + e
                if y == 1:
                    x = -x
                if count != 0:#this part draws them under normal circumstances
                    screen.blit(font.render(str(zoom),True,Colours["Black"]),(720+x*50 + Origin[0]- len(str(zoom))*6 ,360+Origin[1]))
                if Origin[1] < -360:#these two parts draw them when the x or y axes go off the screen
                    screen.blit(font.render(str(zoom),True,Colours["Black"]),(720+x*50 + Origin[0]- len(str(zoom))*6,0))
                if Origin[1] > 350:
                    screen.blit(font.render(str(zoom),True,Colours["Black"]),(720+x*50 + Origin[0]- len(str(zoom))*6,710))
                if y == 0:
                    count += 5#done since coordinates are drawn every 50 coordinates, this is for the positive x coordinates
                else:
                    count -= 5#negative x coordinates
        if y > 1:
            for x in range(10+int(math.fabs(Origin[1]/10))):#the coordinates up the y axis
                if count/Scroll %1 == 0:
                    zoom = int(count/Scroll)
                else:
                    zoom = count/Scroll
                if y == 2:
                    x = -x
                screen.blit(font.render(str(zoom),True,Colours["Black"]),(720+Origin[0]- len(str(zoom))*6,360+x*50 + Origin[1]))
                if Origin[0] < -350:
                    screen.blit(font.render(str(zoom),True,Colours["Black"]),(360,360+x*50 + Origin[1]))
                if Origin[0] > 350:
                    screen.blit(font.render(str(zoom),True,Colours["Black"]),(1080-len(str(zoom))*6,360+x*50 + Origin[1]))
                if y == 2:
                    count += 5#positive y coordinates
                else:
                    count -= 5#negative y coordinates
        count = 0

def BracketCheck(Equation):#confirms number of open brackets to closed brackets is even
    BracketCheck = [0,0]
    for x in Equation:
        if x == "(":
            BracketCheck[0] += 1#counts open brackets
        elif x == ")":
            BracketCheck[1] += 1#counts close brackets
    if BracketCheck[0] != BracketCheck[1]:#when there is an uneven number of open and close brackets
        if BracketCheck[0] > BracketCheck[1]:
            Equation +=")"*(BracketCheck[0] - BracketCheck[1])#increases close brackets by adding them to the end
        elif BracketCheck[0] < BracketCheck[1]:
            Equation == Equation.replace(")","",-(BracketCheck[1]-BracketCheck[0]))#replaces the latest closed brackets until the number is even
    return Equation

def Rearranger(Equation, Origin,Scroll):#this part of the program makes the graph appropriate for reading
    Equation = Equation.replace("^a","^")
    Equation = Equation.replace("|","@")
    Equation = Equation.replace("atnh","math.atanh(")
    Equation = Equation.replace("asnh","math.asinh(")
    Equation = Equation.replace("acsh","math.acosh(")
    Equation = Equation.replace("down","D")
##    print Equation
    Int = ["0","1","2","3","4","5","6","7","8","9","."]#all char accepted as numbers, when adjacent they will be joined together
    Trig = ["asin","acos","atan","sin","cos","tan"]
    Equation = Equation.replace(" ","")
    Equation = Equation.replace("***","**")#corrects a specific error caused in equation entering'
    TempList = []
    Temp = ""
    Log = ""
    for l in Equation:#marks a lograrithm
        if l == "l" or l == "o" or l == "g":
            if l == "l":
                Log = "l"
            elif l == "o" and Log == "l":
                Log += "o"
            elif l == "g" and Log == "lo":
                Log += "g"
        elif Log == "log":
            Temp += l
        else:
            if Log == "log":
                TempList.append(Temp)
            Temp = ""
            Log = ""
    Simp = [0,0]
    for p in range(len(Equation)):
        if Equation[p] in ["^","/",",",]:
            Simp[0] += 1
        if Equation[p] == "R":
            Simp[1] += 1
    while True:
        if Simp[0] > Simp[1]:
            Equation += "R"
            Simp[1] += 1
        else:
            break
    Form = []
    FormOne = ["))",")",",",")"]
    for x in Equation:
        if x == "/":
            Form.append(0)
        elif x == "^":
            Form.append(1)
        elif x == "l":
            Form.append(2)
        elif x == "q":
            Form.append(3)
    for x in Trig:
        Equation = Equation.replace(x,"math." + x+"(")
    Equation = Equation.replace("ln","math.log(")
    Equation = Equation.replace("^","^(")
    Equation = Equation.replace("log","math.log(")
    Equation = Equation.replace("pi","math.pi")
    print Equation
    for x in range(len(Form)):#this part of the program makes sure that when the user exits
        Equation = Equation.replace("R",FormOne[Form[-x-1]],1)
    print Equation
    Equation = Equation.replace("/","((")
    Equation = Equation.replace("D",")/(")
    Equation = Equation.replace("q","math.sqrt(")
    Equation = Equation.replace("math.math.","math.")
    Equation = Equation.replace("R","")
    Equation = BracketCheck(Equation)
    Equation = Equation.replace("math.amath.","math.a")
    Equation = Equation.replace("(h","h(")
##    print Equation
    count = 1
    num = [0,0]
    Init = ["",""]
    bracket = [False,0,2]
    for r in Equation:#a procedure that flips the conditions of logarithms (math library codes with base as second argument, which is not how it is displayed
        if r == ",":
            Temp,TempOne = Equation.split(",",count)
            L = 0
            for x in Temp[::-1]:
                if x == "(" and num[0] == num[1]:
                    Init[0] = Temp[::-1][:L]
                    bracket = [False,0]
                    break
                elif x == ")":
                    num[0] += 1
                elif x == "(" and num[0] != num[1]:
                    num[1] += 1
                L += 1
            L = 0
            num = [0,0]
            for x in TempOne:
                if x == ")" and num[0] == num[1]:
                    Init[1] = TempOne[:L]
                    break
                elif x == ")":
                    num[0] += 1
                elif x == "(" and num[0] != num[1]:
                    num[1] += 1
                L += 1
            Equation = Equation.replace(Init[0][::-1]+","+Init[1],Init[1]+","+Init[0][::-1])
    EquationList = list(Equation)
    count = 0
    for x in EquationList:
        if x == "@":#this for loop ensures that the modulus operation is coded properly, this is hard as every odd modulus bracket must be coded differently from the ven ones
            if count % 2 == 0:
                EquationList[EquationList.index(x)] ="math.fabs("
            else:
                EquationList[EquationList.index(x)] =")"
            count +=1
    count = 1
    try:
        y = EquationList[0]
        for x in EquationList[1:]:
            if x =="(":
                if y == ")" or y == "x" or y == "e":
                    EquationList[count] ="*("
            y = x
            count +=1
        count = 1
        y = EquationList[0]
        for x in EquationList[1:]:
            if x ==")":
                if (y == "(" or y == "x" or y == "m") and EquationList[x+1] not in ["+","-","*"]:
                    EquationList[count] =")*"
            y = x
            count +=1
    except:
        pass
    for x in EquationList:
        if x =="^":
            Bracket = False
    Count = 0
    count = 0
    Equation = "".join(EquationList)
    FinalEquation = []
    Integer = False
    LocalStore = []#this section is used for joining numbers and converting them to floats
    for letters in Equation:
        if letters in Int:
            Integer == True
            LocalStore.append(letters)#creates a temporary list to bind the numbers
        if letters not in Int:
            Integer = False
            Float = True
            if LocalStore != []:
                for t in range(len(LocalStore)):
                    if LocalStore[t] == ".":
                        Float = False
                if Float == True:
                    LocalStore.append(".0")#converts all numbers to floats
            FinalEquation.append("".join(LocalStore))
            if LocalStore:#this allows for multiplication without explicitly using the * sign
                if letters not in ["/","*","+","-","=","(",")",".","^",","]:#exceptions
                    FinalEquation.append("*")
            FinalEquation.append(letters)
            LocalStore = []
    FinalEquation.append("".join(LocalStore))
##    print FinalEquation
    try:
        for letters in FinalEquation:
            StringEquation = "".join(FinalEquation)
            StringEquation = StringEquation.replace("^","**")
            StringEquation = StringEquation.replace("e","math.e")
            if StringEquation.endswith("*"):
                StringEquation = StringEquation[:-1]
            FinalEquation = StringEquation
        x = float(10)
        if FinalEquation[-1] == "-" or FinalEquation[-1] == "+" or FinalEquation[-1] == "*":
            FinalEquation = FinalEquation[:-1]
        FinalEquation += "-"+str(Origin[1]/x/Scroll)#varies the pan in the y direction
        FinalEquation = FinalEquation.replace("x","(x-"+str(Origin[0]/x/Scroll)+")")#varies the pan in the x direction
        FinalEquation = FinalEquation.replace("x","(x/"+str(Scroll)+")")#varies the zoom in the y direction
        FinalEquation = "(" + FinalEquation + ")*"+ str(Scroll)#varies the zoom in the x direction
        FinalEquation = FinalEquation.replace(")m",")*m")
        y = ""
        for x in FinalEquation:
            if x != "(" and y == "g":
                FinalEquation = FinalEquation.replace("g","g(")
            y = x
        FinalEquation = FinalEquation.replace(")*/",")/")#last minute error corrections
        FinalEquation = FinalEquation.replace(")*)","))")
        FinalEquation = FinalEquation.replace(")(",")*(")
        FinalEquation = FinalEquation.replace("h.*","h.")
##        print FinalEquation
        return FinalEquation
    except:
        pass

def Pan(Drag,Tab,Switch,mouse,click,OriginChange,OriginChangeOne,OriginOne,Origin):#controls the pan function
    if Drag == True and Tab == False:
        Origin[0] = OriginOne[0] + OriginChangeOne[0] - OriginChange[0]#finds displacement in x direction
        Origin[1] = OriginOne[1] +  OriginChangeOne[1] - OriginChange[1]#finds displacement in y direction
    if click[0] == 1 and mouse[0] > 360 and Tab == False:#sets drag to true and finds start point of pan
        if Switch == 0:#prevents pan from taking every change from the
            OriginChange = [mouse[0],mouse[1]]
            if Drag == False:
                OriginChangeOne = OriginChange
        else:
            OriginChangeOne = [mouse[0],mouse[1]]
            if Drag == False:
                OriginChange = OriginChangeOne
        Switch += 1
        Drag = True
    if click[0] == 0 and Drag == True:#stops pan
        Switch = 0
        OriginOne[0] +=  OriginChangeOne[0] - OriginChange[0]#final position of pan
        OriginOne[1] +=  OriginChangeOne[1] - OriginChange[1]
        OriginChange = [0,0]
        OriginChangeOne = [0,0]
        Drag = False
    return Origin,Drag,OriginChange,OriginChangeOne,OriginOne,Switch

def Main(): #main program block
    pygame.init()
    Equation= ""#the latest equation
    EquationList = []#the list of all equations except the latest
    Drag = False#drag is drue when the mouse is held down in the grid section, allows for panning
    Tab = False#true when user hovers over buttons, allows access to buttons that do not fit on screen
    TabOne = 0#finds when tab changes from true to false initially
    question = 1#the number of equationd
    Pass = False#prevents buttons from being entered several times on a single click
    ScrollY = 0#the scroll factor for the equation tab
    Question = 0#the currently selected equation
    buttons = pygame.sprite.Group()
    buttonsone = pygame.sprite.Group()#the sprite groups used for the buttons
    quitbuttons = pygame.sprite.Group()
    Switch = 0#keeps pan level
    OriginOne = [0,0]#keeps pan from reseting when it is clicked again
    intermediate = pygame.surface.Surface((360, 480))#the surface that displays the equations and allows them to be scrolled
    tab = pygame.surface.Surface((720,240))#the surface used in the pop out tab, stores buttons
    OriginChange = [0,0]#these two lists are alternated between to keep pan from increasing massively
    OriginChangeOne = [0,0]#only the change from one to the next is measured
    Scroll = 1.0#coefficent of zoom on graph
    ScrollOne = 1#finds when scroll changes
    Start = False#set to true after first user input
    ColourCount = 0#counts graphs so they can each be a different colour
    Origin = [0,0]#the displacement from the centre of the graph
    Colours = {"White":(255,255,255),"GridGrey":(200,200,200),"Black":(0,0,0),"Grey":(50,50,50),"Green":(0,255,0),"CoordGrey":(127,127,127)}#colours used for basic format
    LineColours = [(255,80,5),(153,0,0),(116,10,255),(0,153,143),(94,241,242),(255,0,16),#variation of distinct colours used for display
    (66,102,0),(255,168,187),(255,164,5),(0,51,128),(194,0,136),(157,204,0),(143,124,0),(128,128,128),(255,204,153),
    (43,206,72),(0,92,49),(25,25,25),(76,0,92),(153,63,0),(0,117,220),(240,163,255)]
    size = (1080, 720)
    screen = pygame.display.set_mode(size)
    font = pygame.font.SysFont("Courier New", 10, False, False)
    done = False#when done = true the program ends
    clock = pygame.time.Clock()
    while not done:
        mouse = pygame.mouse.get_pos()#finds mouse position
        click = pygame.mouse.get_pressed()#finds click status
        mouseOne = [mouse[0],mouse[1]-480]
        if Start == False:
            Key = get_key(Scroll,ScrollY,0,0)
            screen.fill(Colours["White"])#initial display before user input
            Grid(screen, Colours,Origin)
            Coordinates(screen, Colours,font,Origin,Scroll)
            Equations(screen, Colours,0,0,intermediate,ScrollY,font)
            tab.fill(Colours["White"])
            Button(screen,intermediate,Colours,font,buttons,buttonsone,quitbuttons,ScrollY).ButtonMaker(buttons,buttonsone,quitbuttons)
            if Key != "" or Scroll != ScrollOne or Drag == True :
                ScrollOne = Scroll
                ScrollYOne = ScrollY
                Type = ""#this is the button string that the button text is added to
                Start = True
        Button(screen,intermediate,Colours,font,buttons,buttonsone,quitbuttons,ScrollY).Update(question)#links to the detection function in the button class, used to find if a button is hovered or clicked
        if click[0] == 0:#click[0] detects left mouse click
                Pass = False
        Type,Close = Button(screen,intermediate,Colours,font,buttons,buttonsone,quitbuttons,ScrollY).Detection(mouse,click,Tab)
        if Key != "" or Scroll != ScrollOne or Drag == True or ScrollY != ScrollYOne or click[0] ==1 or TabOne == 1 or Loop == True:#when any change is made to the program
            Loop = False
            TabOne = 0
            intermediate = pygame.surface.Surface((360, 480+(question-5)*70))#redraws the intermediate surface with updares
            ScrollOne = Scroll
            ScrollYOne = ScrollY#measures change in variables
            font = pygame.font.SysFont("Courier New", 20, False, False)#adds letters in 'Key' to
            EquationOne,EquationListOne, question,Question = Enter(screen ,question,font,Colours,Key,EquationList,Equation,intermediate,Question)
            font = pygame.font.SysFont("Courier New", 10, False, False)
            if Close[1] == True and Pass == False and click[0] == 1:#deletes equations
                if Close[0] == "t":#when there is only one equation
                    EquationOne = ""
                else:
                    if Close[0] <= len(EquationListOne):#most cases
                        del EquationListOne[Close[0]-1]
                    elif Close[0] > len(EquationListOne):#when user deletes last equation
                        try:
                            EquationOne = "".join(EquationListOne[-1])
                            del EquationListOne[-1]
                        except:
                            Equation = ""
                        Question = 0
                Close = [0,False]
                Pass = True
                question -= 1
                ScrollY = max(0,ScrollY - 70)
                Loop = True
            Equation = EquationOne
            screen.fill(Colours["White"])#display is cleared with every update
            intermediate.fill(Colours["White"])
            Grid(screen, Colours,Origin)
            Coordinates(screen, Colours,font,Origin,Scroll)#basic display drawn
            Equations(screen, Colours,EquationOne,EquationListOne,intermediate,ScrollY,font)
            font = pygame.font.SysFont("Courier New", 20, False, False)
            FinishCount = 0
            Type = Type.replace(" ","")#removes any spaces in the buttons
            if Pass == False and Type != "" and Key == "":
                Type = Type.replace("rght","R")
                Type = Type.replace("down","D")#changes the text from the buttons into terms readable to the program
                Type = Type.replace("sqrt","q")
                if Type == "C":#removes last character
                    if Question == 0:
                        Equation = Equation[:-1]
                    else:
                        del EquationList[Question-1][-1]
                elif Type == "CE":#this empties the equation
                    if Question == 0:
                        Equation = ""
                    else:
                        EquationList[Question-1] = ""
                else:
                    if Question == 0:
                        Equation += Type#this adds the clicked buttons text to the equation
                    else:
                        EquationList[Question-1] += Type
                Pass = True
            Equation = Equation.replace("sinhsinh","sinh")
            Equation = Equation.replace("coshcosh","cosh")
            Equation = Equation.replace("tanhtanh","tanh")#these "replace" functions fix the strings habit of repeating with a single mouse click
            Equation = Equation.replace("asnhasnh","asnh")
            Equation = Equation.replace("acshacsh","acsh")
            Equation = Equation.replace("atnhatnh","atnh")
            pygame.draw.circle(intermediate, LineColours[FinishCount], (25,75+(70*FinishCount+1)),20,1)#draws circle that marks graph to line
            TextBox(screen, str(question) + ": y= " + "".join(Equation) ,font,Colours, question,intermediate,Question,FinishCount)
            try:
                question = 1#updates equation tab with equations
                for a in EquationList:
                    FinishCount +=1
                    pygame.draw.circle(intermediate, LineColours[FinishCount], (25, 75+(70*FinishCount+1)), 20, 1)
                    TextBox(screen, str(question) + ": y= " + "".join(a),font,Colours, question,intermediate,Question,FinishCount)
                    question +=1
            except:
                pass
            font = pygame.font.SysFont("Courier New", 10, True, False)
            FinalEquation = []
            for b in EquationList:#passes each equation through rearranger function
                FinalEquation.append(Rearranger("".join(b),Origin,Scroll))
            FinalEquation.append(Rearranger(Equation,Origin,Scroll))
            ColourCount = 0
            for c in FinalEquation:#draws each equation
                Line(screen, LineColours,ColourCount, c,Scroll,Origin)
                ColourCount += 1
        screen.blit(intermediate, (0,ScrollY))
        Tab,TabOne = Button(screen,intermediate,Colours,font,buttons,buttonsone,quitbuttons,ScrollY).Place(mouse,click,Tab,TabOne)
        Temp = []
        try:
            for z in EquationListOne:
                Temp.append("".join(z))
        except:
            pass
        for x in range(len(Temp)+1):
            pygame.draw.line(intermediate, Colours["GridGrey"], (0,110+x*70),(360, 110+x*70),1)#draws line between equation boxes
        pygame.draw.rect(screen, Colours["White"], (0, 0, 360, 40))
        pygame.draw.rect(screen, Colours["GridGrey"], (0, 0, 360, 40),1)
        mouse = pygame.mouse.get_pos()
        Origin, Drag,OriginChange,OriginChangeOne,OriginOne ,Switch = Pan(Drag,Tab,Switch,mouse,click,OriginChange,OriginChangeOne,OriginOne,Origin)
        Key, Scroll,ScrollY = get_key(Scroll,ScrollY,EquationOne,EquationListOne)#links to getkey
        if click[0] == 1 and mouse[0] <= 360 and mouse[1] <= 480:
            for d in range(max(len(FinalEquation),7)):
                if  110 + d*70 > mouse[1] > 40 +d*70:
                    Question = 1 + d - ScrollY/70#selects any but the last equation when clicked
            if Question == question:
                Question = 0#seclects the last question when it is clicked
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True#loop deciding when program ends
        if len(EquationList) == 0:
            Question = 0
        pygame.display.flip()
        clock.tick(40)#amount of times the program updates every second
    pygame.quit()
Main()#start of program